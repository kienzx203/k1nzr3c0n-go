# binary-exploitation

Lines|Files|Path (đọc repo/binary-exploitation/<path>)
---|---|---
3457|20|libc-heap
2774|9|ios-exploiting
2477|5|libc-heap/heap-memory-functions
2106|10|.
1251|6|rop-return-oriented-programing
1029|5|stack-overflow
980|7|linux-kernel-exploitation
831|7|arbitrary-write-2-exec
740|3|format-strings
694|2|stack-overflow/ret2win
624|2|basic-stack-binary-exploitation-methodology
574|3|common-binary-protections-and-bypasses/aslr
550|2|rop-return-oriented-programing/ret2lib/rop-leaking-libc-address
532|6|common-binary-protections-and-bypasses
500|3|rop-return-oriented-programing/ret2lib
477|2|basic-stack-binary-exploitation-methodology/tools
428|2|rop-return-oriented-programing/srop-sigreturn-oriented-programming
338|2|stack-overflow/stack-shellcode
334|2|rop-return-oriented-programing/rop-syscall-execv
267|3|common-binary-protections-and-bypasses/stack-canaries
179|2|libc-heap/use-after-free
156|2|common-binary-protections-and-bypasses/pie
