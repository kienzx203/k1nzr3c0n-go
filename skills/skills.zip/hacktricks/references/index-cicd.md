# pentesting-ci-cd

Lines|Files|Path (đọc repo/pentesting-ci-cd/<path>)
---|---|---
3616|11|.
1566|5|github-security/abusing-github-actions
961|7|jenkins-security
851|3|github-security
787|1|teamcity-security
748|4|cloudflare-security
726|4|concourse-security
377|3|apache-airflow-security
360|2|okta-security
277|2|gitea-security
177|2|chef-automate-security
174|2|travisci-security
158|2|gitblit-security
122|1|gogs-security
