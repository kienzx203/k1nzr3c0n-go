# permission-categorizations

Lines|Files|Path (đọc repo/permission-categorizations/<path>)
---|---|---
36|1|.
