# generic-hacking

Lines|Files|Path (đọc repo/generic-hacking/<path>)
---|---|---
3091|6|.
1693|6|reverse-shells
