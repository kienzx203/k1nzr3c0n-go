# macos-hardening

Lines|Files|Path (đọc repo/macos-hardening/<path>)
---|---|---
3723|12|macos-security-and-privilege-escalation/macos-security-protections
3636|23|macos-security-and-privilege-escalation/macos-proces-abuse
2274|4|macos-security-and-privilege-escalation/macos-security-protections/macos-tcc
2248|4|macos-security-and-privilege-escalation/macos-apps-inspecting-debugging-and-fuzzing
2016|2|.
1977|10|macos-security-and-privilege-escalation
1925|3|macos-security-and-privilege-escalation/macos-proces-abuse/macos-ipc-inter-process-communication
1756|6|macos-security-and-privilege-escalation/macos-files-folders-and-binaries
1229|6|macos-security-and-privilege-escalation/mac-os-architecture
972|2|macos-security-and-privilege-escalation/macos-proces-abuse/macos-ipc-inter-process-communication/macos-xpc
858|3|macos-security-and-privilege-escalation/macos-proces-abuse/macos-library-injection
712|2|macos-security-and-privilege-escalation/macos-security-protections/macos-fs-tricks
658|3|macos-security-and-privilege-escalation/macos-proces-abuse/macos-ipc-inter-process-communication/macos-xpc/macos-xpc-connecting-process-check
627|2|macos-security-and-privilege-escalation/macos-security-protections/macos-tcc/macos-tcc-bypasses
577|2|macos-security-and-privilege-escalation/macos-security-protections/macos-sandbox/macos-sandbox-debug-and-bypass
538|2|macos-security-and-privilege-escalation/macos-security-protections/macos-sandbox
393|2|macos-red-teaming
353|3|macos-red-teaming/macos-mdm
