# generic-methodologies-and-resources

Lines|Files|Path (đọc repo/generic-methodologies-and-resources/<path>)
---|---|---
10579|31|pentesting-wifi
4063|14|pentesting-network
3801|10|basic-forensic-methodology
2363|10|phishing-methodology
2258|14|basic-forensic-methodology/specific-software-file-type-tricks
1826|4|python/bypass-python-sandboxes
1764|9|python
1340|4|external-recon-methodology
954|2|basic-forensic-methodology/memory-dump-analysis
948|6|basic-forensic-methodology/pcap-inspection
866|4|.
658|2|basic-forensic-methodology/windows-forensics
425|2|basic-forensic-methodology/partitions-file-systems-carving
130|1|lua/bypass-lua-sandboxes
