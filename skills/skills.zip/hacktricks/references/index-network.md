# network-services-pentesting

Lines|Files|Path (đọc repo/network-services-pentesting/<path>)
---|---|---
17162|89|.
14305|60|pentesting-web
2640|16|pentesting-web/php-tricks-esp/php-useful-functions-disable_functions-open_basedir-bypass
1306|3|pentesting-smb
1088|2|pentesting-mssql-microsoft-sql-server
1019|4|pentesting-web/electron-desktop-apps
997|3|pentesting-smtp
828|3|pentesting-web/php-tricks-esp
703|1|pentesting-voip
584|3|pentesting-ftp
572|3|pentesting-snmp
467|2|pentesting-voip/basic-voip-protocols
404|2|pentesting-web/drupal
342|2|11211-memcache
336|3|pentesting-kerberos-88
270|1|pentesting-web/tomcat
225|1|pentesting-web/sitecore
27|2|pentesting-web/buckets
