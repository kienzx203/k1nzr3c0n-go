# pentesting-web

Lines|Files|Path (đọc repo/pentesting-web/<path>)
---|---|---
14681|53|.
5645|19|xss-cross-site-scripting
4466|15|deserialization
2821|9|xs-search
2160|4|ssrf-server-side-request-forgery
1881|3|ssti-server-side-template-injection
1875|6|sql-injection
1798|5|browser-extension-pentesting-methodology
1538|4|deserialization/nodejs-proto-prototype-pollution
1330|3|http-request-smuggling
1282|3|xs-search/css-injection
1237|7|sql-injection/postgresql-injection
1009|2|content-security-policy-csp-bypass
983|2|login-bypass
951|10|file-inclusion
834|2|saml-attacks
780|3|cache-deception
755|5|postmessage-vulnerabilities
648|4|hacking-with-cookies
455|2|pocs-and-polygloths-cheatsheet
428|2|sql-injection/sqlmap
375|2|unicode-injection
339|2|sql-injection/mysql-injection
282|2|dangling-markup-html-scriptless-injection
15|2|file-upload
