# windows-hardening

Lines|Files|Path (đọc repo/windows-hardening/<path>)
---|---|---
8195|31|windows-local-privilege-escalation
7756|41|active-directory-methodology
3231|7|.
1813|5|active-directory-methodology/ad-certificates
1167|4|windows-local-privilege-escalation/dll-hijacking
1072|4|stealing-credentials
971|8|lateral-movement
820|2|basic-powershell-for-pentesters
742|2|authentication-credentials-uac-and-efs
633|3|active-directory-methodology/acl-persistence-abuse
591|2|ntlm
