# File Integrity Monitoring

{{#include ../../banners/hacktricks-training.md}}

## Baseline

A baseline consists of taking a snapshot of certain parts of a system to **compare it with a future status to highlight changes**.

For example, you can calculate and store the hash of each file of the filesystem to be able to find out which files were modified.\
This can also be done with the user accounts created, processes running, services running and any other thing that shouldn't change much, or at all.

A **useful baseline** usually stores more than just a digest: permissions, owner, group, timestamps, inode, symlink target, ACLs, and selected extended attributes are also worth tracking.<sup>[[4]](#references)</sup> From an attacker-hunting perspective, this helps detect **permission-only tampering**, **atomic file replacement**, and **persistence via modified service/unit files** even when the content hash is not the first thing that changes.

### File Integrity Monitoring

File Integrity Monitoring (FIM) is a critical security technique that protects IT environments and data by tracking changes in files. It usually combines:<sup>[[1]](#references)[[3]](#references)</sup>

1. **Baseline comparison:** Store metadata and cryptographic checksums (prefer `SHA-256` or better) for future comparisons.
2. **Real-time notifications:** Subscribe to OS-native file events to know **which file changed, when, and ideally which process/user touched it**.
3. **Periodic re-scan:** Rebuild confidence after reboots, dropped events, agent outages, or deliberate anti-forensic activity.

For threat hunting, FIM is usually more useful when focused on **high-value paths** such as:

- `/etc`, `/boot`, `/usr/local/bin`, `/usr/local/sbin`
- `systemd` units, cron locations, SSH material, PAM modules, web roots
- Windows persistence locations, service binaries, scheduled task files, startup folders
- Container writable layers and bind-mounted secrets/configuration

## Real-Time Backends & Blind Spots

### Linux

The collection backend matters:<sup>[[2]](#references)[[9]](#references)</sup>

- **`inotify` / `fsnotify`**: easy and common, but watch limits can be exhausted and some edge cases are missed.
- **`auditd` / audit framework**: better when you need **who changed the file** (login UID, process ID, and process name).
- **`eBPF` / `kprobes`**: newer options used by modern FIM stacks to enrich events and reduce some of the operational pain of plain `inotify` deployments.

Some practical gotchas:<sup>[[1]](#references)[[5]](#references)</sup>

- If a program **replaces** a file with `write temp -> rename`, watching the file itself may stop being useful. **Watch the parent directory**, not only the file.
- `inotify`-based collectors can miss or degrade on **huge directory trees**, **hard-link activity**, or after a **watched file is deleted**.
- Very large recursive watch sets can silently fail if `fs.inotify.max_user_watches`, `max_user_instances`, or `max_queued_events` are too low.
- For `inotify`-based monitoring, network filesystems are a blind spot because remote changes are not reported.

Example baseline + verification with AIDE:<sup>[[4]](#references)</sup>

```bash
aide --init
mv /var/lib/aide/aide.db.new /var/lib/aide/aide.db
aide --check
```

Example `osquery` FIM configuration focused on attacker persistence paths:<sup>[[1]](#references)</sup>

```json
{
  "schedule": {
    "fim": {
      "query": "SELECT * FROM file_events;",
      "interval": 300,
      "removed": false
    }
  },
  "file_paths": {
    "etc": ["/etc/%%"],
    "systemd": ["/etc/systemd/system/%%", "/usr/lib/systemd/system/%%"],
    "ssh": ["/root/.ssh/%%", "/home/%/.ssh/%%"]
  }
}
```

If you need **process attribution** instead of only path-level changes, prefer audit-backed telemetry such as `osquery` `process_file_events` or Wazuh `whodata` mode.<sup>[[1]](#references)[[3]](#references)[[9]](#references)</sup>

#### `io_uring`: syscall telemetry is not FIM

On modern Linux, watching `openat(2)`, `write(2)`, or other syscall entry points is **not equivalent to monitoring the resulting filesystem operation**. The 2025 **Curing** proof of concept queued file and network requests through `io_uring`, so products or policies attached only to the corresponding per-operation syscall entries lost process telemetry. In the same tests, a path-scoped FIM component still observed file modifications, showing that this is a **hook-placement blind spot**, not a permission bypass or a way to defeat every FIM backend.<sup>[[10]](#references)</sup>

When validating a sensor, modify the same canary through several paths: normal `write`, `mmap` + `msync`, `truncate`, `sendfile`/`copy_file_range`, atomic replacement, and `io_uring`. Check not only that the final hash drift is found, but also whether the event preserves the responsible process, container/cgroup, namespace-visible path, inode, and rename pair. A missing real-time event followed by a periodic-scan mismatch must be treated as **telemetry loss**, not as a routine unexplained change.<sup>[[10]](#references)[[11]](#references)</sup>

For eBPF-based monitoring, prefer common kernel enforcement points over a list of syscall-entry probes. For example, Tetragon's file-access policy uses `security_file_permission` to cover ordinary I/O, `sendfile`, `copy_file_range`, AIO, and `io_uring`; it separately covers memory mappings with `security_mmap_file` and size changes with `security_path_truncate`. This also illustrates why one hook is rarely complete coverage.<sup>[[11]](#references)</sup>

### Windows

On Windows, FIM is stronger when you combine **change journals** with **high-signal process/file telemetry**:<sup>[[6]](#references)[[7]](#references)</sup>

- **NTFS USN Journal** gives a persistent per-volume log of file changes.
- **Sysmon Event ID 11** is useful for file creation/overwrite.
- **Sysmon Event ID 2** helps detect **timestomping**.
- **Sysmon Event ID 15** is useful for **named alternate data streams (ADS)** such as `Zone.Identifier` or hidden payload streams.

Quick USN triage examples:<sup>[[7]](#references)</sup>

```cmd
fsutil usn queryjournal C:
fsutil usn readjournal C:
fsutil usn readdata C:\Windows\Temp\sample.bin
```

For deeper anti-forensic ideas around **timestamp manipulation**, **ADS abuse**, and **USN tampering**, check [Anti-Forensic Techniques](anti-forensic-techniques.md).

### Containers

Container FIM frequently misses the real write path. With Docker `overlay2`, the container filesystem combines read-only image `lowerdir` layers with a writable **upper layer** (`upperdir`/`diff`), and writes to image files are copied up into that upper layer.<sup>[[8]](#references)</sup> Therefore:

- Monitoring only paths from **inside** a short-lived container may miss changes after the container is recreated.
- Monitoring the **host path** that backs the writable layer or the relevant bind-mounted volume is often more useful.
- FIM on image layers is different from FIM on the running container filesystem.

## Attacker-Oriented Hunting Notes

- Track **service definitions** and **task schedulers** as carefully as binaries. Attackers often get persistence by modifying a unit file, cron entry, or task XML rather than patching `/bin/sshd`.
- A content hash alone is insufficient. Many compromises first show up as **owner/mode/xattr/ACL drift**.
- If you suspect a mature intrusion, do both: **real-time FIM** for fresh activity and a **cold baseline comparison** from trusted media.
- If the attacker has root or kernel execution, treat the FIM agent and its database as untrusted. Store logs and baselines remotely or on read-only media whenever possible.<sup>[[4]](#references)</sup>

## Tools

- [AIDE](https://aide.github.io/)
- [osquery](https://osquery.io/)
- [Wazuh FIM / Syscheck](https://documentation.wazuh.com/current/user-manual/capabilities/file-integrity/index.html).<sup>[[3]](#references)</sup>
- [Elastic Auditbeat File Integrity Module](https://www.elastic.co/docs/reference/beats/auditbeat/auditbeat-module-file_integrity)
- [Sysmon](https://learn.microsoft.com/en-us/sysinternals/downloads/sysmon)

## References

- [1] [File Integrity Monitoring with osquery](https://osquery.readthedocs.io/en/stable/deployment/file-integrity-monitoring/)
- [2] [Tracing Linux: A file integrity monitoring use case (Elastic)](https://www.elastic.co/blog/tracing-linux-file-integrity-monitoring-use-case)
- [3] [Wazuh File Integrity Monitoring (Syscheck and whodata mode)](https://documentation.wazuh.com/current/user-manual/capabilities/file-integrity/index.html)
- [4] [AIDE Manual Version 0.16.2](https://aide.github.io/doc/)
- [5] [inotify(7) Linux manual page](https://man7.org/linux/man-pages/man7/inotify.7.html)
- [6] [Sysmon](https://learn.microsoft.com/en-us/sysinternals/downloads/sysmon)
- [7] [fsutil usn](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/fsutil-usn)
- [8] [OverlayFS storage driver](https://docs.docker.com/engine/storage/drivers/overlayfs-driver/)
- [9] [Wazuh FIM advanced settings](https://documentation.wazuh.com/current/user-manual/capabilities/file-integrity/advanced-settings.html)
- [10] [io_uring Rootkit Bypasses Linux Security Tools (ARMO)](https://www.armosec.io/blog/io_uring-rootkit-bypasses-linux-security/)
- [11] [Filename access: covering synchronous, asynchronous, mapped, and truncation paths (Tetragon)](https://tetragon.io/docs/use-cases/filename-access/)

{{#include ../../banners/hacktricks-training.md}}
